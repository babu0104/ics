import 'rxjs/add/operator/toPromise';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { IcsResponse } from '../../interfaces/manual-entry-response/icsresponse';
import { ApplicationFraud } from '../../interfaces/manual-entry-response/applicationfraud';
import { CreditResponse } from '../../interfaces/manual-entry-response/creditresponse';
import { CreditCard } from '../../interfaces/manual-entry-response/creditcard';
import { BankruptcyAlert } from '../../interfaces/manual-entry-response/bankruptcyalert';

@Injectable()
export class ManualResponse {
	constructor(private http: HttpClient) { }

	getICSresponse() {
		return this.http.get<any>('assets/data/responsedata/icsresponse.json')
			.toPromise()
			.then(res => <IcsResponse[]>res.icsdata)
			.then(icsdata => { return icsdata; });
	}
	getApplicationfraud() {
		return this.http.get<any>('assets/data/responsedata/icsresponse.json')
			.toPromise()
			.then(res => <ApplicationFraud[]>res.frauddata)
			.then(frauddata => { return frauddata; });
	}
	getCreditcard() {
		return this.http.get<any>('assets/data/responsedata/icsresponse.json')
			.toPromise()
			.then(res => <CreditCard[]>res.creditcard)
			.then(creditcard => { return creditcard; });
	}
	getCreditresponse() {
		return this.http.get<any>('assets/data/responsedata/icsresponse.json')
			.toPromise()
			.then(res => <CreditResponse[]>res.creditdata)
			.then(creditdata => { return creditdata; });
	}
	getBankruptcyalert() {
		return this.http.get<any>('assets/data/responsedata/icsresponse.json')
			.toPromise()
			.then(res => <BankruptcyAlert[]>res.bankruptcyalert)
			.then(bankruptcyalert => { return bankruptcyalert; });
	}

}