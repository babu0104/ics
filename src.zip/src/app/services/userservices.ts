import 'rxjs/add/operator/toPromise';

import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Injectable } from '@angular/core';

import { UserAdmin } from '../interfaces/user-admin';

import { Observable } from 'rxjs/Rx';

@Injectable()
export class UserService {
	private loggedInUserRoleId: any;

	constructor(private http: Http) { }

	setLoggedInUserRoleId(roleId) {
		this.loggedInUserRoleId = roleId;
	}

	getLoggedInUserRoleId() {
		return this.loggedInUserRoleId;
	}

	getUsers(loggedInUserRoleId, page, size, searchValue): Observable<any> {
		let data = { 'roleId': loggedInUserRoleId };
		if (size === undefined) {
			return this.http.post("http://10.129.155.104:8080/user/ListUser/page?page=" + page + "&size=&searchTerm=", data).map(res => res.json());
		} else {
			let search;
			if (searchValue === undefined) {
				search = "page=" + page + "&size=" + size + "&searchTerm=";
			} else {
				search = "page=" + page + "&size=" + size + "&searchTerm=" + searchValue;
			}
			return this.http.post("http://10.129.155.104:8080/user/ListUser/page?" + search, data).map(res => res.json());
		}
	}

	getUserRoleById(roleId): Observable<any> {
		let actionValue = "update";
		let data = { 'roleId': roleId };
		return this.http.post('http://10.129.155.104:8080/user/rolesbyId?action=' + actionValue, data)
			.map(res => res.json())
	}
}
