import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class templateOptionProvider {
    Source: any[];
    responseObject : object = {};
    
    constructor(private _http: HttpClient, ) { }

    getAllOptions() {
        //The Actual Service call goes here
        this.Source = [
                                { name : 'SSN', id : '123' , value : 'ssn'},
                                { name : 'First Name', id : '123' , value : 'first_name'},
                                { name : 'Middle Name', id : '123' , value : 'middle_name'},
                                { name : 'Last Name', id : '123' , value : 'last_name'},
                                { name : 'Address Line 1', id : '123' , value : 'add_1'},
                                { name : 'Address Line 2', id : '123' , value : 'add_2'},
                                { name : 'City', id : '123' , value : 'city'},
                                
                            ];
        return this.Source;


        
    }
}