import { Component, OnInit, ElementRef } from '@angular/core';
import { CalendarModule } from 'primeng/primeng';
import { User } from '../../interfaces/user';
import { UserService } from '../../services/userservices';
import { ObjectUtils } from '../../util';
import { Router } from '@angular/router';
declare var $: any;
@Component({
	selector: 'app-view-records',
	templateUrl: './view-records.component.html',
	styleUrls: ['./view-records.component.scss']
})
export class ViewRecordsComponent implements OnInit {
	utilObject: ObjectUtils;
	title = 'app';
	resultDate: any;
	targetValue: any;
	loading: boolean;
	deadline: Date;
	users: User[];
	cols: any[];
	phonenumber1: string;
	ssnNumber: string;
	ssn() {
		if (this.ssnNumber !== undefined) {
			let sliceTemp = this.ssnNumber.slice(0, 6);
			this.ssnNumber = this.ssnNumber.replace(sliceTemp, 'XXX-XXX');
		}
	}
	search() {
		let records = document.getElementsByClassName('record-table');
		records[0].classList.add('display-table');
	}
	constructor(private userService: UserService, private elRef: ElementRef, private router: Router) {
		this.utilObject = new ObjectUtils();
	}

	onCancel(event) {
		this.router.navigate(['/ics-home/home-page']);
	}

	ngOnInit() {

		this.loading = true;
		// setTimeout(() => {
		// 	this.userService.getUsers().subscribe(users => this.users = users);
		// 	console.log(this.users);
		// 	this.loading = false;
		// }, 1000);

		this.cols = [
			{ field: 'name', header: 'Name' },
			{ field: 'userID', header: 'userID' },
			{ field: 'role', header: 'role' },
			{ field: 'service', header: 'service' },
			{ field: 'created', header: 'created' },
			{ field: 'modified', header: 'modified' },
			{ field: 'last_login', header: 'last_login' },
			{ field: 'status', header: 'status' }
		];
	}


	onkeyup(event) {
		this.utilObject.onFocus(event.target.value, this.elRef.nativeElement, event.keyCode);
	}


}
