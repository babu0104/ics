import { Component, OnInit,TemplateRef } from '@angular/core';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { PickListModule } from 'primeng/primeng';
import { templateOptionProvider } from '../../services/templateoptionprovider.serivce';

import {User} from '../../interfaces/user';
import {UserService} from '../../services/userservices';


@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss'],
  providers : [templateOptionProvider],
})
export class FileUploadComponent implements OnInit {
  
  uploadedFiles: any[] = [];

  sourceOption: any [];
  targetOption: any [];

  isFileTypeChanged : boolean;
  isCustomSubmissionChanged : boolean;
  SelectedFileType : string;

  public modalRef: BsModalRef;

  onUpload(event) {
      for(let file of event.files) {
          this.uploadedFiles.push(file);
      }
  }

  constructor(private modalService: BsModalService, private _templateOptionProvider : templateOptionProvider ) {

   }

  ngOnInit() {    
    //assign false by default
    this.isCustomSubmissionChanged = false;
    console.log(this.isCustomSubmissionChanged + 'onload');
    setTimeout(() => {
      this.sourceOption = this._templateOptionProvider.getAllOptions();
      console.log(this.sourceOption);
    }, 1000);

    this.targetOption = [];
  }

  public openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }
  
  public closeModal() {
    this.modalRef.hide();
  }
  
  onFileTypeChange(event){
    let _self = this;
    let selected = event.currentTarget.value;
    if(selected.toLowerCase() == 'custom'){
      this.isFileTypeChanged = true;
      this.SelectedFileType = selected;
    } else{
      this.isFileTypeChanged = false;
      this.SelectedFileType = selected;
    }
    this.isCustomSubmissionChanged = true;
    console.log(this.isCustomSubmissionChanged + 'onchange');
    
  }

  onFixedWidthChage(event){
    console.log(event);
  }
  oncommaDelimeterChange(event){
    console.log(event);
  }
  onSubmissionTypeChange(event){
    this.isCustomSubmissionChanged = true;
  }

  onSelectCustomTemplate(event){
    let self = this;

  }

  setSelectTemplateDisabled(e){
    let self = this;
    console.log('disbaling');
    document.getElementById('select-template').setAttribute('disabled', 'disabled');
  }

}
