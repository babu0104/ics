import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manual-entry-header',
  templateUrl: './manual-entry-header.component.html',
  styleUrls: ['./manual-entry-header.component.scss']
})
export class ManualEntryHeaderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
