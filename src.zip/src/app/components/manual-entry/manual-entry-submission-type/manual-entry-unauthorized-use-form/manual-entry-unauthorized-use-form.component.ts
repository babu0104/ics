import { Component, OnInit, ElementRef, Directive, forwardRef, Attribute, OnChanges, SimpleChanges, Input } from '@angular/core';
import { NG_VALIDATORS, Validator, Validators, AbstractControl, ValidatorFn } from '@angular/forms';
import { ObjectUtils } from '../../../../util';
import { User } from '../../../../User';
import { Router } from '@angular/router';
declare var $: any;

@Component({
  selector: 'app-manual-entry-unauthorized-use-form',
  templateUrl: './manual-entry-unauthorized-use-form.component.html',
  styleUrls: ['./manual-entry-unauthorized-use-form.component.scss']
})
export class ManualEntryUnauthorizedUseFormComponent implements OnInit {
  utilObject: ObjectUtils;
  resultDate: any;
  targetValue: any;
  phonenumber1: string;
  phonenumber2: string;
  user = new User();
  sec_count: number = 0;
  phone_count: number = 0;

  constructor(private elRef: ElementRef, private router: Router) {
    this.utilObject = new ObjectUtils();
  }
  onCancel(event) {
    this.router.navigate(['/ics-home/home-page']);
  }
  ngOnInit() { }
  onkeyup(event) {
    this.utilObject.onFocus(event.target.value, this.elRef.nativeElement, event.keyCode);
  }
  submitted = false;
  onSubmit() { this.submitted = true; }

  address() {
    this.sec_count = this.sec_count + 1;
    let sec = document.getElementsByClassName('sec-address');
    sec[0].classList.add('show');
    let add_btn = document.getElementsByClassName('add-btn');
    add_btn[0].classList.add('disable');
  }

  phone() {
    this.phone_count = this.phone_count + 1;
    let phone = document.getElementsByClassName('sec-phone');
    phone[this.phone_count - 1].classList.add('show');
    if (this.phone_count === 2) {
      let add = document.getElementsByClassName('phone-btn');
      add[0].classList.add('disable');
    }
  }

}