import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoadReloadComponent } from './load-reload.component';


describe('LoadReloadComponent', () => {
  let component: LoadReloadComponent;
  let fixture: ComponentFixture<LoadReloadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoadReloadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoadReloadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
