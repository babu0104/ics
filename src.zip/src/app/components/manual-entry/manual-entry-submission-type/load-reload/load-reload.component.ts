import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-load-reload',
  templateUrl: './load-reload.component.html',
  styleUrls: ['./load-reload.component.scss']
})
export class LoadReloadComponent implements OnInit {
  phonenumber1: string;
  phonenumber2: string;
  constructor() { }

  ngOnInit() {
  }

}
