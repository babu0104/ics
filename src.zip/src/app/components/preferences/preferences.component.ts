import { Component, OnInit, ElementRef,Directive, forwardRef, Attribute,OnChanges, SimpleChanges,Input } from '@angular/core';
import { NG_VALIDATORS,Validator,Validators,AbstractControl,ValidatorFn } from '@angular/forms';
import { ObjectUtils } from '../../util';
import { Router } from '@angular/router';
import { PreferencesModel } from './preferences.model';
import { UserPreference } from '../../interfaces/admin_preferences/userpreference';
import { AdminPreferencesService } from '../../services/Admin_Preference/adminpreferences.sevice';

@Component({
  selector: 'app-preferences',
  templateUrl: './preferences.component.html',
  styleUrls: ['./preferences.component.scss'],
  providers: [AdminPreferencesService]
})
export class PreferencesComponent implements OnInit {
  utilObject: ObjectUtils;
  modelObj: PreferencesModel;
  preference: UserPreference[];
  responseData: any;
  helperArray = [];
  resultDate = {};
  targetValue: any;
  //defaultMso: string;
  images: any;

  constructor(private elRef: ElementRef, private router: Router, private adminpreferencesservice: AdminPreferencesService) {
    this.utilObject = new ObjectUtils();
    this.modelObj = new PreferencesModel();
  }

  ngOnInit() {
    this.modelObj.defaultService = "";
    this.modelObj.defaultBin = "";
    this.modelObj.submissionType = "";
    this.modelObj.msodefaultBin = "";
    this.modelObj.msoBin = "";
    this.modelObj.purgedefaultBin = "";
    this.modelObj.purgeBin = "";
    this.Load();
  }

  onCancel(event) {
    this.router.navigate(['/ics-home/home-page']);
  }
  getSelectedOption() {
    for (let key in this.helperArray) {
      this.modelObj.defaultService = this.helperArray[key].user_settings[key].user_dservice;
      this.modelObj.defaultBin = this.helperArray[key].user_settings[key].user_dbin;
      this.modelObj.submissionType = this.helperArray[key].user_settings[key].user_type;
      this.modelObj.selectMSO = this.helperArray[key].user_settings[key].user_mso;
      this.modelObj.msodefaultBin = this.helperArray[key].MSO_settings[key].mso_dbin;
      this.modelObj.msoBin = this.helperArray[key].MSO_settings[key].mso_bin;
      this.modelObj.purgedefaultBin =this.helperArray[key].purge_settings[key].purge_dbin;
      this.modelObj.purgeBin=this.helperArray[key].purge_settings[key].purge_bin;  
      
    }

  }
  Load() {
      this.adminpreferencesservice.getUsers().subscribe(data => {
      /*for (let key in data) {*/
      this.helperArray.push(data);
      //console.log(this.helperArray);
      this.getSelectedOption();
      /*}*/
    });

  }


  onkeyup(event) {
    this.utilObject.onFocus(event.target.value, this.elRef.nativeElement, event.keyCode);
  }
  /*getUpdate()
  {
    this.modelObj.selectMSO=this.defaultMso;
    this.modelObj.MSOdata=this.MSOdetails;
    this.adminObj.bindPreferences(this.modelObj);
  }*/


  MSOs: string[] = ['Blank',
    'A-MSO - A',
    'B-MSO - Bb b',
    'C-MSO - Casdf',
    'D-MSO - D',
    'E-MSO - E',
    'F-MSO - F',
    'G-MSO - G',
    'H-MSO - H',
    'I-MSO - I',
    'J-MSO - J',
    'K-MSO - K',
    'L-MSO - L',
    'M-MSO - M',
    'N-MSO - N',
    'O-MSO - O',
    'P-MSO - P',
    'Q-MSO - Q',
    'R-MSO - R',
    'S-MSO - Saturday',
    'T-MSO - T - TOM',
    'U-MSO - U',
    'V-MSO - V - VISA',
    'W-MSO - W',
    'X-MSO - X',
    'Y-MSO - Y',
    'Z-MSO - Z',];

  filteredMSOs: any[];

  MSO: string;

  filterMSOs(event) {
    this.filteredMSOs = [];
    for (let i = 0; i < this.MSOs.length; i++) {
      let MSO = this.MSOs[i];
      if (MSO.toLowerCase().indexOf(event.query.toLowerCase()) == 0) {
        this.filteredMSOs.push(MSO);
      }
    }
  }
   submitted = false; //form not submited : default
    data: string; //this variable contains our data

    //Show data after form submit and set submitted to true
    onSubmit(data) {
        this.submitted = true;
        this.data = JSON.stringify(data, null, 2);
        this.postJson(this.data);
    }
    postJson(getJson:any)
    {
      console.log(getJson);
    }

}

