import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { IcsHomeComponent } from './ics-home.component';

describe('IcsHomeComponent', () => {
  let component: IcsHomeComponent;
  let fixture: ComponentFixture<IcsHomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ IcsHomeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IcsHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
