import { Component, OnInit,HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { UserLoginService } from '../../services/userLoginService';
import { AuthenticationService, Auth_UserService } from '../../_services/index';
import { UserService } from '../../services/userservices';
import { User } from '../../_models/user';
import { Role } from '../../_models/Role';
import * as _ from 'underscore';
import { PlatformLocation } from '@angular/common'

@Component({
  selector: 'app-ics-home',
  templateUrl: './ics-home.component.html',
  styleUrls: ['./ics-home.component.scss']
})
export class IcsHomeComponent implements OnInit {
  userModel = new User();
  roleModel = new Role();
  map: any;
  public token: string;

  public showHome: boolean;
  public showSubmitData: boolean;
  public showManualentry: boolean;
  public showFileupload: boolean;
  public showViewRecords: boolean;
  public showReceiveFiles: boolean;
  public showAdmin: boolean;
  public showUserAdmin: boolean;
  public showPreferences: boolean;
  public showReports: boolean;
  loginCancelled: boolean = true;


  constructor(private router: Router,
  private userService: Auth_UserService, 
  private authService: AuthenticationService,
  private loggedInUserService: UserService,
  private location: PlatformLocation,
  private userLoginService: UserLoginService) {   
  }
  sub: any;
  role: string;
  roleId: string;

  ngOnInit() {
    let _self = this;
    let result = [];
   
    var currentUser = JSON.parse(localStorage.getItem('currentUser'));
    //getRoleService
    this.userService.fetchRole()
      .subscribe(map => {
        Object.keys(map.roleObj).forEach(key => {

          if (map.roleObj[key].userName === currentUser.userName) {
            _self.role = map.roleObj[key].role;
            _self.setNavigation(_self.role);
            _self.roleId = map.roleObj[key].roleId;
            this.loggedInUserService.setLoggedInUserRoleId(_self.roleId);
          } else
            console.log('role doesnot macth');
        });
      });
  }
  setNavigation(role) {
    //debugger;

    switch (role) {
      case "issuer admin": {
        console.log("Excellent");
        break;
      }
      case "general user":
      case "processor":
      case "visa user": {
        console.log("general user");
        this.showHome = true;
        this.showSubmitData = true;
        this.showManualentry = true;
        this.showFileupload = true;
        this.showViewRecords = true;
        this.showReceiveFiles = true;
        this.showAdmin = true;
        this.showUserAdmin = true;
        this.showPreferences = true;
        this.showReports = true;
        break;
      }
      case "visa master":
      case "visa admin": {
        console.log("visa master");
        this.showHome = false;
        this.showSubmitData = false;
        this.showManualentry = false;
        this.showFileupload = false;
        this.showViewRecords = false;
        this.showReceiveFiles = false;
        this.showAdmin = true;
        this.showUserAdmin = true;
        this.showPreferences = true;
        this.showReports = false;
        break;
      }
      default: {
        console.log("Invalid Role");
        break;
      }
    }
  }

}
