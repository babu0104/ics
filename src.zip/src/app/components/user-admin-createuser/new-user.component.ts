import { Component, Directive, forwardRef, Attribute, OnChanges, SimpleChanges, Input, OnInit, TemplateRef } from '@angular/core';
import { NG_VALIDATORS, Validator, Validators, AbstractControl, ValidatorFn } from '@angular/forms';
import { Router } from '@angular/router';
import { Headers, Response, RequestOptions, URLSearchParams, Http } from '@angular/http';
import { BsModalRef, BsModalService } from 'ngx-bootstrap/modal';
import { SecurityImage } from '../../interfaces/user-admin-images';
import { UserAdmin } from '../../interfaces/user-admin';
import { UserService } from '../../services/userservices';
import { CreateUser } from '../../create-user';
import { userRoleService } from '../../services/user-roles-services';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
// import * as _ from 'underscore';
import { Message } from 'primeng/components/common/api';
import { MessageService } from 'primeng/components/common/messageservice';

import { DatePipe } from '@angular/common';

import { SubmissionType } from '../../interfaces/admin_preferences/submissiontype';

import * as $ from 'jquery';
import * as _ from 'lodash'; 
 



@Component({
  moduleId: module.id,
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./new-user.component.scss'],
  providers: [userRoleService, MessageService]
})


export class NewUserComponent implements OnInit {
  selectedBin = [];
  allowedBid:SubmissionType[];
  allowedSubmissionType=[];
  showBins:boolean;
  showSubmission:boolean;
  allowedBins=[];
  msgs: Message[] = [];
  commonError: boolean;
  images: any[];
  public modalRef: BsModalRef;
  securityImageUrl: any;
  selectedImageUrl: any;
  showUserAdmin: boolean = false;
  showNewUser: boolean = true;
  loading: boolean;
  users: any[];
  cols: any[];
  roles: any[];
  bids: any[];
  submissiontypes: any[];
  selectedBids: any[];
  selectedBins: any[];
  selectedSubmitTypes: any[];
  createuser = new CreateUser();
  userRoles: any;
  selectedRole: any;
  loggedInUserRoleId: string;
  currentBin:number;
  binList = [];
  inArr = [];
  subTypes = [];
  showSubm : boolean;
  sortOrder: string = 'asc';
  sortItem:string = '';

  hierarchy=[];
  filteredData=[];
  date: string;
  
  constructor(private router: Router, 
  private modalService: BsModalService, 
  private userService: UserService, 
  private http: Http, 
  private userRoleService: userRoleService, 
  private messageService: MessageService) {
    // this.images = [
    //   { imgname: '1' }, { imgname: '3' }, { imgname: '4' }, { imgname: '5' }, { imgname: '6' },
    //   { imgname: '7' }, { imgname: '8' }, { imgname: '9' }, { imgname: '10' }, { imgname: '11' },
    //   { imgname: '12' }, { imgname: '13' }, { imgname: '14' }, { imgname: '15' },
    //   { imgname: '16' }, { imgname: '17' }, { imgname: '18' }, { imgname: '19' }, { imgname: '20' },
    //   { imgname: '21' }, { imgname: '22' }, { imgname: '23' }, { imgname: '24' }, { imgname: '25' },
    //   { imgname: '26' }, { imgname: '27' }, { imgname: '28' }, { imgname: '29' }
    // ];


    this.date = 'currentDate'

    let dp = new DatePipe('de-DE' /* locale .. */);
    this.date = dp.transform(new Date(), 'dd-MM-yyyy');
    console.log(this.date);

  }

  ngOnInit() {
    
    this.commonError = false;
    this.loading = true;
    this.createuser.ics = "0";
    this.createuser.pcs = "0";
    
    
    this.getuserrole();
    
  /*** Table data1 ***/
		setTimeout(() => {
			this.userRoleService.getSubmission().then(result => this.allowedBid = result);
			this.loading = false;
		}, 1000);
			
		/*this.cols = [
		        {field: 'BID', header: 'BIDs'}
		];*/
		/*** Table data1 ***/


    this.http.get("assets/data/hierarchy.json")
            .subscribe((data)=> {
                setTimeout(()=> {
                    this.hierarchy = data.json();
                    this.filteredData=this.hierarchy;
                    console.log(this.filteredData);
                    /*this.filteredData.forEach( 
                       (item,index) => item.index=index+1 
                     );*/
                }, 1000);
            });

  }
  getuserrole() {
    this.loggedInUserRoleId= this.userService.getLoggedInUserRoleId();
    this.userRoleService.getuserrole(this.loggedInUserRoleId).subscribe(res => {
      this.roles = res;
      this.userRoles = this.roles;
    });
  }


  //select image
  backToUserAdmin() {
    this.showUserAdmin = !this.showUserAdmin;
    this.showNewUser = !this.showNewUser;
  }

  selectImage(image: any) {
    this.selectedImageUrl.setAttribute('src', image.src);
  }

  setImage() {
    this.securityImageUrl.setAttribute('src', this.selectedImageUrl.getAttribute('src'));
    this.closeModal();
  }


  // checkbox
  public openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);


this.userRoleService.getAllImages().subscribe(res => {
      this.images = res;
    });


    this.securityImageUrl = document.getElementById('security-image');
    this.selectedImageUrl = document.getElementById('selected-image');

    this.selectedImageUrl.setAttribute('src', this.securityImageUrl.getAttribute('src'));
  }

  public closeModal() {
    this.modalRef.hide();
  }

  // form submit
  submitted = false; //form not submited : default
  data: any; //this variable contains our data

  //Show data after form submit and set submitted to true
  onSubmit(data) {
    this.submitted = true;

    // appending the selected bids/bins/submit types to data json, to be send to the server
    if (!_.isUndefined(this.selectedBids) && this.selectedBids.length != 0) {
      data['bid'] = this.selectedBids;
    }
    if (!_.isUndefined(this.selectedBins) && this.selectedBins.length != 0) {
      data['bin'] = this.selectedBins;
    }
    if (!_.isUndefined(this.selectedSubmitTypes) && this.selectedSubmitTypes.length != 0) {
      data['submitType'] = this.selectedSubmitTypes;
    }

    this.selectedRole = this.userRoles.filter(function (node) {
      return node.roleDesc == data.roleDesc;
    });

    data['roleDto'] = Object.assign({}, this.selectedRole[0]);
    delete data['roleDesc'];
    data['ics'] = data.ics ? "1" : "0";
    data['pcs'] = data.pcs ? "1" : "0";
    data['secImg'] = "1";
    data['lastModifiedDate'] = this.date;
    //data['lastLoginDate'] = this.date;
    data['usercreationDate'] = this.date;
    data['password'] = "QWERT$#@!";


    //this.data = JSON.stringify(data);
    let headers = new Headers({ 'Content-Type': 'application/json' });
    let options = new RequestOptions({ headers: headers });

    //let actionValue = "create";
    this.http.post('http://10.129.155.104:8080/user/createUser', JSON.stringify(data), options).subscribe(
      data => {
        this.showSuccess();
      },
      err => {
        this.showError();
      }
    );
    
        console.log(data);
  }
    showSuccess() {
    this.msgs = [];
    this.msgs.push({ severity: 'success', summary: 'Success!', detail: 'User updation successfull' });
  }

  showError() {
    this.msgs = [];
    this.msgs.push({ severity: 'error', summary: 'Error!', detail: 'User updation failed' });
  }

  onRowSelect(event:any){
    this.showBins=true;
    this.showSubmission=false;
    let bId = event.data.BID;
    let binListArray = this.getBins( bId );
    //this.binList pushhhh
    if(_.isArray(binListArray) && !_.isUndefined(binListArray)){
      debugger;
    } else {
     // alert("Error Occured while fetching Bin");
    }
    $(document).on("click",".ui-accordion-header p-header .checkmark",function(event){
          //alert('hi');
         
            if ($(this).prev().is(':checked')) {
                  $(this).prev().prop("checked",false);
                  $(this).parents(".ui-accordion-header").next().find('.child').prop("checked",false);
            }
            else
            {
                  $(this).prev().prop("checked",true);  
            }
           
    });
     
  }
  getBins ( bid ){
    let selectedBid = ( _.isUndefined(bid) || _.isNull(bid) ) ? null : bid ;
    this.userRoleService
        .getBinList( selectedBid )
        .subscribe(res => {
            this.binList = res ;
        });
     
      $(document).on("click",".child",function() {
          let $parent;
          $parent = $(this).parents(".ng-trigger-tabContent").prev(".ui-state-active").find('input[type="checkbox"]');
          if ($(this).is(":checked")) $parent.prop("checked",true);
          else {
            var len = $(this).parents(".ng-trigger-tabContent").find(".child:checked").length;
            $parent.prop("checked",len>0);
          }    
      });
      
      
  
    
  }
  
  onRowUnSelect(event:any)
  {
     this.subTypes=[];
     this.inArr=[];
     this.showSubmission=false;
     this.showBins=false;
     this.showSubm=false;
     this.allowedBins=[];
  }

  private sortByWordLength = (a:any) => {
        return a.name.length;
    }
    
    public removeItem(item: any) {
      this.hierarchy = _.filter(this.hierarchy, (elem)=>elem!=item);
      this.filteredData = this.hierarchy;
    }
    
    public updateData(query:string) {
      if(query) {
        this.filteredData = _.filter(this.hierarchy, (a)=>a.name.indexOf(query)>=0);
      } else {
        this.filteredData = this.hierarchy;
      }
    }

    public moveUp(value,index:number)
    {
      if(index>0)
      {
        //alert(index);
        const temp=this.filteredData[index-1];
        this.filteredData[index-1]=this.filteredData[index];
        this.filteredData[index]=temp;
        console.log(this.filteredData);
      }
    }
    public moveDown(value,index:number)
    {
      if(index<this.filteredData.length)
      {
       // alert(index);
        const temp=this.filteredData[index+1];
        this.filteredData[index+1]=this.filteredData[index];
        this.filteredData[index]=temp;
        console.log(this.filteredData);
      }
    }

      public sort(item:string, type:string){
            debugger;
            this.sortOrder = type;
            this.sortItem = item;
            if(item === 'name'){
              this.filteredData = _.orderBy(this.filteredData, [(e) =>(e.name).toLowerCase()], [this.sortOrder]);
            } else if(item === 'email'){
              this.filteredData = _.orderBy(this.filteredData, [(e) =>(e.email).toLowerCase()], [this.sortOrder]);
            }
          //   this.sortOrder 
          //   if (this.filteredData) {
          //     return this.filteredData.sort((a, b) => {
          //       if(a.name.toLowerCase() < b.name.toLowerCase()) return -1;
          //       if(a.name.toLowerCase() > b.name.toLowerCase()) return 1;
          //       return 0;
          //     } );
          // } else {
          //     return this.filteredData;
          // }
        
      }
}
