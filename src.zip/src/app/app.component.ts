import { Component, OnInit } from '@angular/core';
import { UserLoginService } from './services/userLoginService';
import { LoginComponent } from './shared/login/login.component';
import { HeaderComponent } from './shared/header/header.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  providers: [UserLoginService]
})
export class AppComponent {
  title = 'app';
  constructor() { }
    ngOnInit() {
    }
  
}
