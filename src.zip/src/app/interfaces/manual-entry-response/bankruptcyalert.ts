export interface BankruptcyAlert {
    details;
    currentstatus;
    countnumber;
    chaptertype;
    namefiled;
    debtindicator;
    bankruptcydisputecode;
}
