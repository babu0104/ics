export interface ApplicationFraud {
    fraudtype;
    matchtype;
    accNo;
    reportDate;
    caseno;
    disputeCode;
}