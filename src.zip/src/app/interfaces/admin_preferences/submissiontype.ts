export class SubmissionType {
    vin;
}