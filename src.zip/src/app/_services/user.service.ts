import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';
import * as _ from 'underscore';
import { Client } from '../http-client.service'

import { AuthenticationService } from '../_services/index';
import { User } from '../_models/index';
import { Role } from '../_models/Role';

@Injectable()
export class Auth_UserService {
    userModel = new User();
    roleModel = new Role();
    public token: string;
    public role:string;
    private subject = new Subject<boolean>();
    constructor(
        private http: Http,
        private authenticationService: AuthenticationService,
        private api : Client
    ) {
    }
    getUsers(): Observable<User[]> {
        // add authorization header with jwt token
        let headers = new Headers({ 'Authorization': 'Bearer ' + this.authenticationService.token });
        let options = new RequestOptions({ headers: headers });

        // get users from api
        return this.http.get('/api/users', options)
            .map((response: Response) => response.json());
    }

    getUserDefaultInfoTest(username: string): Observable<JSON>{
        let userName = !_.isUndefined(username) ? username : '';
        //debugger;
        let headerOption;
        console.log('user naeme received from login '+ userName);
        return this.http.get('../assets/data/userinfo.json')
        // headerOption = this.api.getRequestOptions('application/json')
        // return this.http.post('/api/authenticate', username)
                .map((res:Response) => 
                res.json()
            );
    }

    login(userobj : any): Observable<any>{
        let userData = userobj;
        console.log('user naeme received from login to getDetail '+ userData);   
        
        localStorage.setItem('id_token', 'jwt-sample-Token'); 
        return  this.http.get('../assets/data/userdetail.json')   // return  this.http.post('/api/authenticate', userData.username)
                .map(function (response : Response) {
                    return response.json();
                });  
    }

    getURLMapping(): Observable<JSON>{  
        return this.http.get('../assets/data/app.urlmap.json')
                .map((res:Response) => res.json());
        
    }

    validateUser(username , password): Observable<boolean>{
        // return this.http.post('/api/authenticate', JSON.stringify({ username: username, password: password }))
        return this.http.get('../assets/data/login.json', JSON.stringify({ username: username, password: password }))
        .map((response: Response) => {
        //debugger;
        if(response.json().userName === username && response.json().password === password){       
            // login successful if there's a jwt token in the response
            let token = response.json() && response.json().token;
            if (token) {
                // set token property
                this.token = token;

                // store username and jwt token in local storage to keep user logged in between page refreshes
                localStorage.setItem('currentUser', JSON.stringify({ userName: username, token: token }));

                // return true to indicate successful login
                return true;
            }
         } else {
                // return false to indicate failed login
                return false;
        }
        });
    }

    fetchRole(): Observable<any>{
        return this.http.get('../assets/data/user-role.json')
        .map((res:Response) => res.json());
    }

    fetchPages(role:string): Observable<any>{
        return this.http.get('../assets/data/app.urlmap.json')
        .map((res) =>{
            let data=res.json();
            const result = [];
            Object.keys(data).forEach( key => {
                if(data[key].role === role){
                    result.push(data[key]);
                }
            });
            return result;
        }); 
    }

    isUserNameExist(){
        let userName = localStorage.getItem('userName');
        if(_.isUndefined(userName) || _.isNull(userName))
            return false;
        else
            return true;
    }

    setUserNameStatus(message: string) {
        // this.subject.next({ text: message });
    }

    getUserNameStatus(): Observable<any> {
        return this.subject.asObservable();
    }
}