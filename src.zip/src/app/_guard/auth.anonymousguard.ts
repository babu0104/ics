import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { AuthenticationService, Auth_UserService } from '../_services/index';
import { User } from '../_models/user';
import { Role } from '../_models/Role';
import * as _ from 'underscore';

@Injectable()
export class AuthAnonymousGuard implements CanActivate {
    userModel = new User();
    roleModel = new Role();
    currentUserName: string;
    role: string;
    pages: any;
    flag: string;
    constructor(private router: Router, private auth: AuthenticationService, private userService: Auth_UserService) {
    }

    canActivate() {
        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (this.auth.loggedIn()) {
            let _self = this;
            _self.userService.fetchRole()
                .subscribe(map => {
                    Object.keys(map.roleObj).forEach(key => {
                        if (map.roleObj[key].userName === currentUser.userName) {
                            _self.role = map.roleObj[key].role;
                            _self.userService.fetchPages(_self.role)
                                .subscribe(result => {
                                    if (result) {
                                        _self.router.navigate(['/' + result[0].default + '/']);
                                    }
                            });
                        }
                    });
                });
        }
        else {
            return true;
        }
    }

}