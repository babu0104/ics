import { Injectable } from '@angular/core';
import { Router, CanActivate, CanActivateChild } from '@angular/router';
import { AuthenticationService, Auth_UserService } from '../_services/index';
import { User } from '../_models/user';
import { Role } from '../_models/Role';
import * as _ from 'underscore';

@Injectable()
export class AuthGuard implements CanActivateChild {
    userModel = new User();
    roleModel = new Role();
    role: string;
    currentUserName :string;
    constructor(private router: Router, private auth: AuthenticationService, private userService : Auth_UserService) { }

    canActivateChildTest(){
        console.log('child routing is calling');
    }

    canActivateChild() {
        console.log('parent routing is calling');
        var currentUser = JSON.parse(localStorage.getItem('currentUser'));
        if (currentUser) {
            let _self = this;
            let changedPathByUser = location.pathname.split('/')[2];
            _self.userService.fetchRole()
                .subscribe(map => {
                    Object.keys(map.roleObj).forEach(key => {
                        if (map.roleObj[key].userName === currentUser.userName) {
                            _self.role = map.roleObj[key].role;
                            _self.userService.fetchPages(_self.role)
                                .subscribe(result => {
                                    if (result) {
                                        var arrayres = _.filter(result[0].pages, function (urlVal) { return urlVal == changedPathByUser; });
                                        if (arrayres.length)
                                            return true;
                                        else
                                            _self.router.navigate(['/' + result[0].default + '/']);
                                    }
                                });
                        }
                    });
                });

            // logged in so return true
            return true;

        }
        // not logged in so redirect to login page
        this.router.navigate(['']);
        return false;
    }
    
    

    
}