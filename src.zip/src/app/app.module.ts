import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { FormsModule } from '@angular/forms';
import { CalendarModule, CarouselModule, DialogModule,CheckboxModule } from 'primeng/primeng';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FileUploadModule } from 'primeng/primeng';
import { UserService } from './services/userservices';
import { ManualResponse } from './services/manual-entry-response/manualresponse';
import { UserLoginService } from './services/userLoginService';
import { MessageService } from './services/message.service';
import { InputMaskModule, PickListModule, AccordionModule,AutoCompleteModule, DataTableModule, SharedModule, TooltipModule, ConfirmDialogModule, GrowlModule, DropdownModule } from 'primeng/primeng';
import { ModalModule } from 'ngx-bootstrap/modal';

import { AngularFontAwesomeModule } from 'angular-font-awesome/angular-font-awesome';
import { AppComponent } from './app.component';
import { HeaderComponent } from './shared/header/header.component';
import { MainComponent } from './shared/main/main.component';
import { FooterComponent } from './shared/footer/footer.component';
import { FaqComponent } from './shared/faq/faq.component';
import { RulesComponent } from './shared/rules/rules.component';

import { RouterModule } from '@angular/router';
import { routes } from './app.routes';
import { HomePageComponent } from './components/home/home-page.component';
import { ManualEntryComponent } from './components/manual-entry/manual-entry.component';
import { ViewRecordsComponent } from './components/view-records/view-records.component';
import { FileUploadComponent } from './components/file-upload/file-upload.component';
import { PreferencesComponent } from './components/preferences/preferences.component';
import { ManualEntryHeaderComponent } from './components/manual-entry/manual-entry-header/manual-entry-header.component';
import { ManualEntrySubmissionTypeComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-submission-type.component';
import { ManualEntryApplicationFormComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-application-form/manual-entry-application-form.component';
import { ManualEntryDeclinedApplicationFormComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-declined-application-form/manual-entry-declined-application-form.component';
import { ManualEntryDeleteComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-delete/manual-entry-delete.component';
import { ManualEntryUnauthorizedUseFormComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-unauthorized-use-form/manual-entry-unauthorized-use-form.component';
import { ManualEntryInquiryFormComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-inquiry-form/manual-entry-inquiry-form.component';
import { ManualEntryDebitInquiryFormComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-debit-inquiry-form/manual-entry-debit-inquiry-form.component';
import { ManualEntryNonBankcardInquiryFormComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-non-bankcard-inquiry-form/manual-entry-non-bankcard-inquiry-form.component';
import { ManualEntryRetroactiveInquiryFormComponent } from './components/manual-entry/manual-entry-submission-type/manual-entry-retro-active-inquiry-form/manual-entry-retro-active-inquiry-form.component';
import { ManualEntryResponseComponent } from './components/manual-entry/manual-entry-response/manual-entry-response.component';


import { LoadReloadComponent } from './components/manual-entry/manual-entry-submission-type/load-reload/load-reload.component';
import { UserAdminComponent } from './components/user-admin/user-admin.component';
import { NewUserComponent } from './components/user-admin-createuser/new-user.component';
import { ReceiveFilesComponent } from './components/receive-files/receive-files.component';
import { ReportsComponent } from './components/reports/reports.component';
import { EditUserComponent } from './components/user-admin-edituser/edit-user.component';


//Log in service part
import { AuthGuard } from '../app/_guard/index';
import { AuthAnonymousGuard } from '../app/_guard/auth.anonymousguard';
import { AuthenticationService, Auth_UserService } from '../app/_services/index';
import { LoginComponent } from './shared/login/login.component';
import { IcsHomeComponent } from './components/ics-home/ics-home.component';
import { BaseRequestOptions } from '@angular/http';
// used to create fake backend
import { fakeBackendProvider } from '../app/_helpers/fake-backend';
import { MockBackend, MockConnection } from '@angular/http/testing';

//client-side service 
import { Client } from '../app/http-client.service';
import { CommonErrorComponent } from './shared/common-error/common-error.component';
import { HelpComponent } from './shared/help/help.component';
import { ContactComponent } from './shared/contact/contact.component';
import { NotFoundComponent } from './shared/not-found/not-found.component';

/*** For login dropdown ***/
import { ClickOutsideModule } from 'ng4-click-outside';

/**** For manual entry service *****/
import { ManualEntryService } from './_services/manualentry.service';
import { TreeModule} from 'primeng/primeng';
import {DataTableModule1} from "angular2-datatable";





@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    MainComponent,
    FooterComponent,
    FaqComponent,
    RulesComponent,
    LoginComponent,
    FileUploadComponent,
    IcsHomeComponent,
    HomePageComponent,
    ManualEntryComponent,
    ViewRecordsComponent,
    ManualEntryComponent,
    FileUploadComponent,
    PreferencesComponent,
    ManualEntryHeaderComponent,
    ManualEntrySubmissionTypeComponent,
    ManualEntryApplicationFormComponent,
    LoadReloadComponent,
    ManualEntryDeclinedApplicationFormComponent,
    ManualEntryDeleteComponent,
    ManualEntryUnauthorizedUseFormComponent,
    ManualEntryInquiryFormComponent,
    ManualEntryDebitInquiryFormComponent,
    ManualEntryNonBankcardInquiryFormComponent,
    ManualEntryRetroactiveInquiryFormComponent,
    UserAdminComponent,
    ReportsComponent,
    ReceiveFilesComponent,
    NewUserComponent,
    EditUserComponent,
    ManualEntryResponseComponent,
    CommonErrorComponent,
    HelpComponent,
    ContactComponent,
    NotFoundComponent
  ],
  imports: [
    DataTableModule1,
    TreeModule,
    HttpModule,
    FormsModule,
    HttpClientModule,
    AccordionModule,
    AutoCompleteModule,
    CalendarModule,
    CarouselModule,
    FileUploadModule,
    InputMaskModule,
    TooltipModule,
    ConfirmDialogModule,
    GrowlModule,
    DropdownModule,
	  BrowserModule,
    BrowserAnimationsModule,
    DataTableModule,
    SharedModule,
    AccordionModule,
    DialogModule,
    CheckboxModule,
    AngularFontAwesomeModule,
    ModalModule.forRoot(),
    PickListModule,
    RouterModule.forRoot(routes),
    ClickOutsideModule
  ],
  exports: [AccordionModule, ModalModule],
  providers: [
    UserService,
    UserLoginService,
    MessageService,
    ManualResponse,
    AuthGuard,
    AuthAnonymousGuard,
    AuthenticationService,
    Auth_UserService,
    BaseRequestOptions,
    Client,
    ManualEntryService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }