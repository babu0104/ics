import { ManualentryList } from './manualentryListNode';

export class RootObject {
    status: number;
    message: string;
    manualentryList: Array<ManualentryList>;

    constructor() { }
}