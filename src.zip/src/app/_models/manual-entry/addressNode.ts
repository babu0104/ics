export class Address {
    primaryaddress1: string;
    primaryaddress2: string;
    secondaryaddress1: string;
    secondaryaddress2: string;

    constructor() { }
}
