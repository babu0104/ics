export class Name {
    firstName: string;
    middleName?: any;
    lastName: string;

    constructor() { }
}
export class Address {
    primaryaddress1: string;
    primaryaddress2: string;
    secondaryaddress1: string;
    secondaryaddress2: string;

    constructor() { }
}
export class FormData {
    name: Array<Name>;
    ssn: string;
    dob: Date;
    address: Array<Address>;
    city: string;
    state: string;
    zip: number;
    phone: number;
    email: string;
    ip: number;
    accountNo: number;
    comments: string;

    constructor() { }
}
export class ManualentryList {
    user_id: number;
    submission_type: string;
    formData: Array<FormData>;

    constructor() { }
}
export class RootObject {
    status: number;
    message: string;
    manualentryList: Array<ManualentryList>;

    constructor() { }
}