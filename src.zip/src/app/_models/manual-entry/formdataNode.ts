import { Address } from './addressNode';
import { Name } from './nameNode';

export class FormData {
    name: Array<Name>;
    ssn: string;
    dob: string;
    address: Array<Address>;
    city: string;
    state: string;
    zip: string;
    phone: string;
    email: string;
    ip: string;
    accountNo: string;
    comments: string;

    constructor() { }
}