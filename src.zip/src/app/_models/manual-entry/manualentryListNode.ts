import { FormData } from './formdataNode';

export class ManualentryList {
    user_id: string;
    submission_type: string;
    formData: Array<FormData>;

    constructor() { }
}