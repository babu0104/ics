import { Component, OnInit ,ElementRef,ViewChild, Renderer} from '@angular/core';
import { PlatformLocation } from '@angular/common'
import { Router } from '@angular/router';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { UserLoginService } from '../../services/userLoginService';
import { NgForm } from '@angular/forms';
import { AuthenticationService, Auth_UserService } from '../../_services/index';
import { User } from '../../_models/user';
import { AuthState } from '../../_models/authstate';
import * as _ from 'underscore';
import { Role } from '../../_models/Role';
import { CommonErrorComponent } from '../common-error/common-error.component';
import { ObjectUtils } from '../../util'


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  providers: [ObjectUtils],
})
export class LoginComponent implements OnInit {
  @ViewChild('myInput') input: ElementRef;
  model = new User();
  authState: AuthState;
  loading = false;
  error = '';
  roleModel = new Role();
  backendErrorStatus: boolean = true;
  userName: any;
  isUserPresent: any;
  loginCancelled: boolean = false;

  constructor(private router: Router,private userLoginService: UserLoginService, private authenticationService: AuthenticationService, private userService: Auth_UserService,private renderer: Renderer,private location: PlatformLocation,private utilObject: ObjectUtils) {
    this.utilObject.hideSignInLink();
    /*location.onPopState(() => {
      debugger;
      let currentURL = this.location.pathname;
      if(currentURL === "/login")
        return false;

      this.model.userName = '';
    });*/
    //this.PreventBack();
  }


  ngOnInit() {
    let _self = this;
    this.userName = localStorage.getItem('userName');
    if(this.userName) 
      this.renderer.invokeElementMethod(this.input.nativeElement, 'focus');
    else
      this.router.navigate(['']);
  }
  PreventBack(){
    history.forward();
  }

  login() {
    let _self = this;
    this.loading = true;
    //let loginactive;
    //service to get username , pwd
    this.userService.validateUser(this.userName, this.model.password)
      .subscribe(result => {
        if (result === true) {
          setTimeout(function () { //temp time delay for spinner
            _self.loading = false;
            _self.router.navigate(['/ics-home/home']);
          }, 1000);

        } else {
          this.error = 'Please fill the password';
          this.loading = false;
        }
      });
  }

  passwordKeyDown(event) {
    if ((!_.isUndefined(event)) && event.keyCode == 13) {
      this.login();
    }
  }
  onCancel(event) {
    this.model.userName = '';
    this.utilObject.clearLocalStorage();
    this.router.navigate(['']);
  }

}
