import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

import { User } from '../../_models/index';
import { AuthState } from '../../_models/authstate';
import { AuthenticationService, Auth_UserService } from '../../_services/index';
import { UserLoginService } from '../../services/userLoginService';
import * as _ from 'underscore';
import { ObjectUtils } from '../../util'

declare var $: any;
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
  providers: [ObjectUtils],
})

export class HeaderComponent implements OnInit {
  model: User = new User();
  authState: AuthState;
  userNameIsValid: boolean;
  userData: any;
  isNameEntered: boolean;
  public token: string;
  showSignIn: boolean;
  isUserPresent: any;

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    private userService: Auth_UserService,
    private userLoginService: UserLoginService,
    private utilObject: ObjectUtils
  ) {
    

  }

  ngOnInit() {
    //oninit check if jwt is present for current user.
    //if it present, make it loggedin true
    //debugger;
    //AuthState.isLoggedIn = this.authenticationService.loggedIn();
    //debugger;
    //this.showSignIn = AuthState.isLoggedIn ? false : true;
  }

  public showOverlay($event): void {
    document.getElementById('UserName_input').focus();
  }

  onSubmit(event) {
    let _self = this;
    let result, obj;
    let userNameVal = this.model.userName;
    let enteredUserName = (userNameVal === undefined || userNameVal.length <= 0) ? false : true;
    if (enteredUserName) {
      localStorage.setItem('userName', userNameVal);
      this.router.navigate(['/login']);
    } else {
      this.model.isUserNamePresent = false;
    }
    this.model.userName = '';
  }
  navToLanding(event){
    if(this.isLoggedIn())
      return false;
    else
      //this.showSignIn = AuthState.isLoggedIn ? false : true;
      this.router.navigate(['']);
  } 

  signOut(event) {
    debugger;
    this.token = null;
    this.utilObject.clearLocalStorage();
    AuthState.isLoggedIn = false;
    //this.showSignIn = AuthState.isLoggedIn ? false : true;
    this.router.navigate(['']);
    
  }

  public isLoggedIn(): boolean {
    let currentUser = localStorage.getItem('currentUser');
    if (_.isNull(currentUser) || _.isUndefined(currentUser))
      this.isUserPresent = false;
    else
      this.isUserPresent = true;

    return this.isUserPresent;
  }
  showSignInForm(event) {
    document.getElementById('sigin-link').classList.toggle('sign-form-show');
  }
  onClickedOutside(e: Event) {
    document.getElementById('sigin-link').classList.remove('sign-form-show');
  }
}
