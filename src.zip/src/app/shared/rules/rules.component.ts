import { Component, OnInit } from '@angular/core';
import { Inject } from '@angular/core';
import { Router } from '@angular/router';
import { ObjectUtils } from '../../util'

@Component({
  selector: 'app-rules',
  templateUrl: './rules.component.html',
  styleUrls: ['./rules.component.scss'],
  providers: [
    { provide: Window, useValue: window },
    ObjectUtils
  ],
})
export class RulesComponent implements OnInit {

  constructor( @Inject(Window) private window: Window,private router: Router,private utilObject : ObjectUtils) {
    this.utilObject.showSignInLink();
   }

  ngOnInit() {
  }

  scroll(el) {
    el.scrollIntoView(true);
    window.scrollBy(0, -60);
  }

  toTop() {
    this.window.document.body.scrollIntoView();
  }
  goback(event) {
    this.router.navigate(['']);
  }
}
